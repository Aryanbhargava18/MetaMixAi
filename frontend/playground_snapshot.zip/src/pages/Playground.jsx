import React, { useMemo, useEffect, useState } from "react";
import api from "../api";

// Hooks
import useFetchModels from "../components/playground/useFetchModels";

// Components
import TopBar from "../components/playground/TopBar";
import ModelSidebar from "../components/playground/ModelSidebar";
import ModelGrid from "../components/playground/ModelGrid";
import ChatTabs from "../components/playground/ChatTabs";
import ChatArea from "../components/playground/ChatArea";
import ParameterPanel from "../components/playground/ParameterPanel";

const MODELS_ENDPOINT = "/api/ai/models";
const CHAT_ENDPOINT = "/api/ai/chat";

export default function Playground() {
  // Fetch models hook
  const {
    models,
    loading: modelsLoading,
    error: modelsError,
  } = useFetchModels(MODELS_ENDPOINT);

  // UI Panels
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [paramsPanelOpen, setParamsPanelOpen] = useState(false);

  // Filters
  const [filters, setFilters] = useState({
    type: "all",
    provider: "any",
    nsfw: "any",
    license: "any",
    tags: "",
    sort: "relevance",
    curated: false,
    verified: false,
    query: "",
    taskTypes: [],
  });

  // Model selection
  const [selectedModel, setSelectedModel] = useState(null);

  // ⭐ Favorites & Compare SET (RESTORED)
  const [favorites, setFavorites] = useState(new Set());
  const [compareSet, setCompareSet] = useState([]);

  // 🎯 Favorites handler
  const handleFavorite = (modelId) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(modelId)) next.delete(modelId);
      else next.add(modelId);
      return next;
    });
  };

  // 🔥 Compare handler
  const handleCompare = (modelId) => {
    setCompareSet((prev) => {
      if (prev.includes(modelId)) {
        return prev.filter((id) => id !== modelId);
      }
      if (prev.length >= 3) {
        return prev; // max 3 models
      }
      return [...prev, modelId];
    });
  };

  // Filters for types and providers
  const types = useMemo(() => {
    const setx = new Set(models.map((m) => m.type || "other"));
    return Array.from(setx);
  }, [models]);

  const providers = useMemo(() => {
    const setx = new Set(
      models
        .map((m) => m.provider_suggestion || "hf-inference")
        .filter(Boolean)
    );
    return Array.from(setx);
  }, [models]);

  // Filtered models (search / type / provider / tasks)
  const filteredModels = useMemo(() => {
    let result = [...models];

    if (filters.query) {
      const q = filters.query.toLowerCase();
      result = result.filter(
        (m) =>
          (m.title || m.name || "").toLowerCase().includes(q) ||
          (m.summary || "").toLowerCase().includes(q) ||
          (m.tags || []).some((t) => t.toLowerCase().includes(q))
      );
    }

    if (filters.type !== "all") {
      result = result.filter((m) => (m.type || "other") === filters.type);
    }

    if (filters.provider !== "any") {
      result = result.filter((m) =>
        (m.provider_suggestion || "")
          .toLowerCase()
          .includes(filters.provider.toLowerCase())
      );
    }

    if (filters.taskTypes.length > 0) {
      result = result.filter((m) => {
        const tags = (m.tags || []).map((t) => t.toLowerCase()).join(" ");
        const pipe = (m.pipeline_tag || "").toLowerCase();
        return filters.taskTypes.some(
          (t) => tags.includes(t.toLowerCase()) || pipe.includes(t.toLowerCase())
        );
      });
    }

    return result;
  }, [models, filters]);

  // Chat tabs
  const [chats, setChats] = useState([]);
  const [activeChatId, setActiveChatId] = useState(null);

  const activeChat = useMemo(
    () => chats.find((c) => c.id === activeChatId),
    [chats, activeChatId]
  );

  const handleSelectModel = (model) => {
    setSelectedModel(model);
    setSidebarOpen(false);

    const id = `chat-${Date.now()}`;
    const newChat = {
      id,
      title: model.title || model.name,
      modelId: model.id,
      messages: [],
    };

    setChats((prev) => [...prev, newChat]);
    setActiveChatId(id);
  };

  // New chat
  const handleNewChat = () => {
    if (!selectedModel) return;

    const id = `chat-${Date.now()}`;
    const newChat = {
      id,
      title: `Chat ${chats.length + 1}`,
      modelId: selectedModel.id,
      messages: [],
    };

    setChats((prev) => [...prev, newChat]);
    setActiveChatId(id);
  };

  // Close chat
  const handleCloseChat = (id) => {
    setChats((prev) => prev.filter((c) => c.id !== id));
    if (activeChatId === id) {
      const remaining = chats.filter((c) => c.id !== id);
      setActiveChatId(remaining.length ? remaining[0].id : null);
    }
  };

  // Params for model chat
  const [params, setParams] = useState({
    temperature: 0.7,
    top_p: 0.9,
    top_k: 40,
    frequency_penalty: 0,
    max_tokens: 1000,
  });

  // Chat loading
  const [loading, setLoading] = useState(false);

  // Send message to backend
  const sendMessage = async (text) => {
    if (!activeChat || !selectedModel) return;

    const userMsg = {
      sender: "user",
      text,
      timestamp: new Date().toISOString(),
    };

    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? { ...c, messages: [...c.messages, userMsg] }
          : c
      )
    );

    setLoading(true);

    try {
      const payload = { modelId: selectedModel.id, prompt: text, ...params };
      const res = await api.post(CHAT_ENDPOINT, payload);

      const botMsg = {
        sender: "bot",
        text: res.data?.content || "No response",
        timestamp: new Date().toISOString(),
      };

      setChats((prev) =>
        prev.map((c) =>
          c.id === activeChatId
            ? { ...c, messages: [...c.messages, botMsg] }
            : c
        )
      );
    } catch (err) {
      const errorMsg = {
        sender: "bot",
        text: "Error: " + (err.response?.data?.message || err.message),
        timestamp: new Date().toISOString(),
      };

      setChats((prev) =>
        prev.map((c) =>
          c.id === activeChatId
            ? { ...c, messages: [...c.messages, errorMsg] }
            : c
        )
      );
    }

    setLoading(false);
  };

  return (
    <div className="h-screen flex flex-col bg-slate-950 text-white overflow-hidden">
      <TopBar
        onNewChat={handleNewChat}
        onOpenSettings={() => setParamsPanelOpen(true)}
        hasActiveChat={!!activeChat}
      />

      <div className="flex-1 flex overflow-hidden">
        {sidebarOpen && (
          <ModelSidebar
            models={models}
            loading={modelsLoading}
            error={modelsError}
            filters={filters}
            setFilters={setFilters}
            onSelectModel={handleSelectModel}
            providers={providers}
            types={types}
            onClose={() => setSidebarOpen(false)}
          />
        )}

        {!activeChat ? (
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="p-6 bg-slate-900 border-b border-slate-700">
              <input
                type="text"
                placeholder="Search models..."
                value={filters.query}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, query: e.target.value }))
                }
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg"
              />
            </div>

            <ModelGrid
              models={filteredModels}
              loading={modelsLoading}
              error={modelsError}
              onSelectModel={handleSelectModel}
              favorites={favorites}
              onFavorite={handleFavorite}
              compareSet={compareSet}
              onCompare={handleCompare}
            />
          </div>
        ) : (
          <div className="flex-1 flex flex-col min-w-0">
            <ChatTabs
              chats={chats}
              activeChatId={activeChatId}
              onSwitch={setActiveChatId}
              onNewChat={handleNewChat}
              onCloseChat={handleCloseChat}
            />

            <ChatArea
              chat={activeChat}
              model={selectedModel}
              onSend={sendMessage}
              loading={loading}
            />
          </div>
        )}

        <ParameterPanel
          params={params}
          setParams={setParams}
          isOpen={paramsPanelOpen}
          onClose={() => setParamsPanelOpen(false)}
        />
      </div>
    </div>
  );
}
