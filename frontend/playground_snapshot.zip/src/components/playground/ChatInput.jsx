import React, { useState } from "react";
import { SendHorizontal } from "lucide-react";

export default function ChatInput({
  input,
  setInput,
  onSend,
  disabled,
}) {
  const [isComposing, setIsComposing] = useState(false);

  const handleKeyDown = (e) => {
    if (isComposing) return;

    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (!disabled && input.trim() !== "") {
        onSend();
      }
    }
  };

  return (
    <div className="p-4 border-t border-slate-700 flex items-end bg-slate-900">
      <div className="relative flex-1">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          onCompositionStart={() => setIsComposing(true)}
          onCompositionEnd={() => setIsComposing(false)}
          rows={1}
          placeholder="Send a message..."
          className="w-full bg-slate-800 border border-slate-700 hover:border-slate-600 focus:border-indigo-500 transition-colors rounded-lg px-4 py-3 text-white resize-none outline-none"
        />
      </div>

      <button
        onClick={onSend}
        disabled={disabled || input.trim() === ""}
        className="ml-3 p-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors shadow-lg"
      >
        <SendHorizontal className="w-5 h-5" />
      </button>
    </div>
  );
}
