import { useState, useEffect } from "react";
import api from "../../api";

export default function useFetchModels(endpoint, attempts = 3) {
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    setError(null);

    const tryFetch = async () => {
      let lastErr = null;

      for (let i = 0; i < attempts; i++) {
        try {
          const res = await api.get(endpoint);
          if (!mounted) return;

          if (res.data?.success) {
            const normalized = (res.data.models || []).map((m) => ({
              ...m,
              image:
                m.image ||
                m.cardData?.images?.[0] ||
                `https://huggingface.co/${m.id}/resolve/main/thumbnail.png` ||
                "/api/ai/static/fallback-image",
              avatar:
                m.image ||
                m.cardData?.images?.[0] ||
                `https://huggingface.co/${m.id}/resolve/main/thumbnail.png`,
            }));

            setModels(normalized);
            setLoading(false);
            return;
          } else {
            throw new Error(res.data?.message || "No models");
          }
        } catch (err) {
          lastErr = err;
          await new Promise((res) => setTimeout(res, 400 + i * 300));
        }
      }

      if (mounted) {
        setError(lastErr?.message || "Failed to fetch models");
        setModels([]);
        setLoading(false);
      }
    };

    tryFetch();
    return () => {
      mounted = false;
    };
  }, [endpoint, attempts]);

  return { models, loading, error };
}
